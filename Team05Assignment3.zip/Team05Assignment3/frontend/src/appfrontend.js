// Author: Cole Stuedeman
//     ISU Netid : colestud@iastate.edu
//     Date :  December 10, 2023
import { useState, useEffect } from "react";
import { BrowserRouter as Router, Route, Routes, Link } from "react-router-dom";

const GET = () => {
  const [product, setProduct] = useState([]);
  const [showClass, setShowClass] = useState("view0");
  const [selectedProduct, setSelectedProduct] = useState(null);
  const [newProduct, setNewProduct] = useState({
    // Initialize with empty values or default values
    title: "",
    category: "",
    price: "",
    description: "",
    rating: "",
    image: "http://127.0.0.1:8081/images/",
  });

  const [editingProduct, setEditingProduct] = useState(null);
  const [editedData, setEditedData] = useState({});

  const handleEdit = (product) => {
    setEditingProduct(product);
    setEditedData({
      title: product.title,
      category: product.category,
      price: product.price,
      description: product.description,
      rating: product.rating,
      image: product.image,
    });
    setShowClass("viewEdit");
  };
  const handleSaveEdit = async () => {
    try {
      const { id } = editingProduct; // Assuming the id is available in editingRobot

      const response = await fetch(
        `http://localhost:8081/updateProduct/${id}`,
        {
          method: "PUT",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(editedData),
        }
      );

      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const result = await response.json();

      // Assuming the result object from the server contains a message property
      console.log(result.message);

      // Refresh the list of robots after editing
      getAllProducts();

      // Switch back to the main view
      setShowClass("view0");
    } catch (error) {
      console.error("Error:", error);
      // Handle error (e.g., display an error message to the user)
    }
  };

  useEffect(() => {
    getAllProducts();
  }, []);

  function getAllProducts() {
    fetch("http://127.0.0.1:8081/api/get")
      .then((response) => response.json())
      .then((data) => {
        console.log("Show Catalog of Products :");
        console.log(data);
        setProduct(data);
      });
  }
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewProduct({
      ...newProduct,
      [name]: value,
    });
  };

  const handleInputChange2 = (e) => {
    const { name, value } = e.target;
    setEditedData({
      ...editedData,
      [name]: value,
    });
  };

  const handleButtonClick2 = (el) => {
    setShowClass("view1");
    setSelectedProduct(el);
  };

  const deleteMethod = (id) => {
    console.log("Let's do Delete ....", id);
    fetch(`http://localhost:8081/deleteProduct/${id}`, {
      method: "DELETE",
      headers: { "content-type": "application/json" },
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
      })
      .then((data) => {
        console.log(data);
        window.location.reload();
      })
      .catch((error) => console.error("Error:", error));
  };

  const handleAddProduct = async () => {
    try {
      // Check if all fields are filled

      const response = await fetch("http://localhost:8081/api/get/");
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }

      const existingProducts = await response.json();
      const newId = existingProducts.length + 1; // Calculate the new ID

      const productToAdd = {
        id: newId,
        ...newProduct,
      };

      const postResponse = await fetch("http://localhost:8081/addProduct", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(productToAdd),
      });

      if (!postResponse.ok) {
        throw new Error(`HTTP error! Status: ${postResponse.status}`);
      }

      const result = await postResponse.json();
      console.log(result);

      // Optionally refresh the list of products after adding a new one
      getAllProducts();

      // Switch back to the main view
      setShowClass("view0");
    } catch (error) {
      console.error("Error:", error);
    }
  };
  const ViewOneItem = () => (
    <div key={selectedProduct.id} className="col">
      <div className="card shadow-sm">
        <img
          src={selectedProduct.image}
          className="bd-placeholder-img card-img-top"
          width="100%"
          height={300}
          alt={selectedProduct.title}
        />
        <div
          className="card-body d-flex flex-column"
          style={{ width: "500px" }}
        >
          <h5 className="card-title text-center">{selectedProduct.title}</h5>
          <p className="card-text text-center">{selectedProduct.category}</p>
          <p className="card-text text-center">
            Price: ${selectedProduct.price}
          </p>
          <p className="card-text text-center">
            Description: {selectedProduct.description}
          </p>
          <p className="card-text text-center">
            Rating: {selectedProduct.rating}
          </p>
        </div>
      </div>
    </div>
  );

  const showAllItems = product.map((el) => (
    <div key={el.id} className="col">
      <div className="card shadow-sm">
        <img
          src={el.image}
          className="bd-placeholder-img card-img-top"
          width="100%"
          height={300}
          alt={el.title} // Use title from your product data
        />
        <div className="card-body d-flex flex-column">
          <h5 className="card-title text-center">{el.title}</h5>
          <p className="card-text text-center">{el.category}</p>
          <div className="d-flex justify-content-between">
            <div className="btn-group">
              <button
                type="button"
                onClick={() => handleButtonClick2(el)}
                className="btn btn-sm btn-primary"
              >
                View Product
              </button>
            </div>

            <div className="btn-group">
              <button
                type="button"
                onClick={() => deleteMethod(el.id)}
                className="btn btn-sm btn-danger"
              >
                Delete Product
              </button>
            </div>

            <div className="btn-group">
              <button
                type="button"
                onClick={() => handleEdit(el)}
                className="btn btn-sm btn-warning" // Change btn-primary to btn-warning
              >
                Edit Product
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  ));

  return (
    <body>
      <header data-bs-theme="dark">
        <div className="navbar navbar-dark bg-dark shadow-sm">
          <div className="container">
            <div className="navbar-brand d-flex align-items-center">
              <button
                type="button"
                onClick={() => {
                  setShowClass("view0");
                }}
                className="btn btn-dark"
              >
                <strong>Cy-Store</strong>
              </button>
            </div>
            <button
              type="button"
              onClick={() => {
                setShowClass("view00");
              }}
              className="btn btn-dark"
            >
              <strong>About Us</strong>
            </button>
          </div>
        </div>
      </header>

      {showClass == "view0" && (
        <div>
          <section className="py-5 text-center container">
            <div className="row py-lg-5">
              <div className="col-lg-6 col-md-8 mx-auto">
                <h1 className="fw-light">Cy-Store</h1>
                <p className="lead text-body-secondary">
                  Welcome to Cy-Store! Take a look at the products or add your
                  own!
                </p>
                <p>
                  <button
                    type="button"
                    onClick={() => {
                      setShowClass("viewAdd"); // Show the add robot form
                    }}
                    className="btn btn-success" // Change btn-primary to btn-success
                  >
                    Create a Product
                  </button>
                </p>
              </div>
            </div>
          </section>
          <script></script>
          <div className="album py-5 bg-body-tertiary">
            <div className="container">
              <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-3">
                {showAllItems}
              </div>
            </div>
          </div>
        </div>
      )}
      {showClass == "view00" && (
        <div className="container">
          <h1>SE/ComS319 Construction of User Interfaces, Fall 2023</h1>
          <p>Date: [12/3/2023]</p>
          <p>
            Complete name of students and ISU email:<br></br> [Cole Stuedeman] -
            [colestu@iastate.edu]
            <br />
            [Josh Whittington] - [joshw3@iatstate.edu]
          </p>
          <p>Dr. Abraham N. Aldaco Gastelum - abraham@iastate.edu</p><br></br><br></br>
          <p>This is assignment 3 for SE/COM S 319. It showcases how we can add, delete, get, and edit fakestore products.</p>
        </div>
      )}

      {showClass == "view1" && (
        <div>
          <div className="text-center mb-4">
            <h1 className="display-4">Cy-Store</h1>
          </div>

          <div className="container d-flex justify-content-center align-items-center vh-100">
            <div className="album py-5 bg-body-tertiary rounded shadow">
              <div className="container">
                <div className="col">{ViewOneItem()}</div>
              </div>
            </div>
          </div>
          <div className="text-center mt-3">
            <button
              type="button"
              onClick={() => {
                setShowClass("view0");
              }}
              className="btn btn-warning"
            >
              Back to All Products
            </button>
          </div>
        </div>
      )}
      {showClass === "viewEdit" && (
        <div>
          <h2 className="text-center">Edit Product</h2>

          <form>
            {/* Form fields for editing the product */}
            <div className="mb-3">
              <label htmlFor="title" className="form-label">
                Title:
              </label>
              <input
                type="text"
                className="form-control"
                id="title"
                name="title"
                value={editedData.title}
                onChange={handleInputChange2}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="price" className="form-label">
                Price:
              </label>
              <input
                type="number"
                className="form-control"
                id="price"
                name="price"
                value={editedData.price}
                onChange={handleInputChange2}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="description" className="form-label">
                Description:
              </label>
              <input
                type="text"
                className="form-control"
                id="description"
                name="description"
                value={editedData.description}
                onChange={handleInputChange2}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="category" className="form-label">
                Category:
              </label>
              <input
                type="text"
                className="form-control"
                id="category"
                name="category"
                value={editedData.category}
                onChange={handleInputChange2}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="image" className="form-label">
                Image URL:
              </label>
              <input
                type="text"
                className="form-control"
                id="image"
                name="image"
                value={editedData.image}
                onChange={handleInputChange2}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="rating" className="form-label">
                Rating:
              </label>
              <input
                type="number"
                className="form-control"
                id="rating"
                name="rating"
                value={editedData.rating}
                onChange={handleInputChange2}
              />
            </div>

            <button
              type="button"
              className="btn btn-primary"
              onClick={handleSaveEdit}
            >
              Update Product
            </button>
            <button
              type="button"
              className="btn btn-danger ms-2"
              onClick={() => setShowClass("view0")}
            >
              Cancel
            </button>
          </form>
        </div>
      )}
      {showClass === "viewAdd" && (
        <div>
          <h2 className="text-center">Add a New Product</h2>

          <form>
            <div className="mb-3">
              <label htmlFor="title" className="form-label">
                Title:
              </label>
              <input
                type="text"
                className="form-control"
                id="title"
                name="title"
                value={newProduct.title}
                onChange={handleInputChange}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="category" className="form-label">
                Category:
              </label>
              <input
                type="text"
                className="form-control"
                id="category"
                name="category"
                value={newProduct.category}
                onChange={handleInputChange}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="price" className="form-label">
                Price:
              </label>
              <input
                type="number"
                className="form-control"
                id="price"
                name="price"
                value={newProduct.price}
                onChange={handleInputChange}
              />
            </div>
            <div className="mb-3">
              <label htmlFor="description" className="form-label">
                Description:
              </label>
              <input
                type="text"
                className="form-control"
                id="description"
                name="description"
                value={newProduct.description}
                onChange={handleInputChange}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="rating" className="form-label">
                Rating:
              </label>
              <input
                type="number"
                className="form-control"
                id="rating"
                name="rating"
                value={newProduct.rating}
                onChange={handleInputChange}
              />
            </div>

            <div className="mb-3">
              <label htmlFor="image" className="form-label">
                Image URL:
              </label>
              <input
                type="text"
                className="form-control"
                id="image"
                name="image"
                value={newProduct.image}
                onChange={handleInputChange}
              />
            </div>

            <button
              type="button"
              className="btn btn-primary"
              onClick={handleAddProduct}
            >
              Add Product
            </button>
            <button
              type="button"
              className="btn btn-danger ms-2"
              onClick={() => setShowClass("view0")}
            >
              Cancel
            </button>
          </form>
        </div>
      )}

      <footer class="text-muted py-5" background-color="rgb(220, 218, 219)">
        <div class="container">
          <p class="float-end mb-1">
            <a href="#">Back to top</a>
          </p>
          <p class="mb-1">Cole Stuedeman and Josh Whittington</p>
          <p class="mb-0"></p>
        </div>
      </footer>
    </body>
  );
};

export default GET;
