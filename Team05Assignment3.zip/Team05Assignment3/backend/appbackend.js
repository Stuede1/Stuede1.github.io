// Author: Cole Stuedeman
//     ISU Netid : colestud@iastate.edu
//     Date :  December 10, 2023
var express = require("express");
var cors = require("cors");
// var app = express();
var fs = require("fs");
var bodyParser = require("body-parser");
const { MongoClient } = require("mongodb");

// Mongo
const url = "mongodb://127.0.0.1:27017";
const dbName = "reactdata";
const client = new MongoClient(url);
const db = client.db(dbName);


const PORT = "8081";
const host = "localhost";

const app = express();


app.use(bodyParser.json());
// const PORT = 4000;
app.use(cors());
app.use(express.json());

app.use(express.static("public"));
app.use("/images", express.static("images"));

app.listen(PORT, () => {
    console.log(`Server is running on ${PORT}`);
});


app.get("/api/get", async (req, res) => {
    await client.connect();
    console.log("Node connected successfully to GET MongoDB");
    const query = {};
    const results = await db
    .collection("fakestore_catalog")
    .find(query)
    .limit(100)
    .toArray();
    console.log(results);
    res.status(200);
    res.send(results);
});

app.get("/:id", async (req, res) => {
    const fakeid = Number(req.params.id);
    console.log("Product to find :", fakeid);

    await client.connect();
    console.log("Node connected successfully to GET-id MongoDB");
    const query = {"id": fakeid };

    const results = await db.collection("fakestore_catalog")
        .findOne(query);

    console.log("Results :", results);
    if (!results) res.send("Not Found").status(404);
    else res.send(results).status(200);
});
// /getFromId





app.post("/addProduct", async (req, res) => {

    await client.connect();
    const maxIdResult = await db.collection("fakestore_catalog").find().sort({ id: -1 }).limit(1).toArray();
    let newId;

    if (maxIdResult.length > 0) {
        // If there's an existing ID, increment it
        newId = maxIdResult[0].id + 1;
    } else {
        // If there are no existing IDs, start from 1
        newId = 1;
    }

    const {
        title,
        price,
        description,
        category,
        image,
        rating
       
    } = req.body;

    const newProduct = {
        id: newId,
        title,
        price,
        description,
        category,
        image,
        rating
    };
    const results = await db.collection("fakestore_catalog").insertOne(newProduct);
    res.status(200);
    res.send(results);



});


app.delete("/deleteProduct/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id); // Use req.params.id to get the ID from URL parameters
  
      const result = await db.collection("fakestore_catalog").deleteOne({ "id": productId }); // Update the collection name if needed
  
      if (result.deletedCount === 1) {
        res.status(200).json({ message: "Product deleted successfully." });
      } else {
        res.status(404).json({ message: "Product not found." });
      }
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });


  app.put("/updateProduct/:id", async (req, res) => {
    try {
      const productId = parseInt(req.params.id);
      const {
        title,
        price,
        description,
        category,
        image,
        rating
       
    } = req.body;
  
    const editProduct = {
        id: productId,
        title,
        price,
        description,
        category,
        image,
        rating
    };
  
      const result = await db
        .collection("fakestore_catalog")
        .updateOne({ id: productId }, { $set: editProduct });
  
      if (result.modifiedCount === 1) {
        res.status(200).json({ message: "Product updated successfully." });
      } else {
        res.status(404).json({ message: "Product not found." });
      }
    } catch (error) {
      console.error("Error:", error);
      res.status(500).json({ error: "Internal Server Error" });
    }
  });
